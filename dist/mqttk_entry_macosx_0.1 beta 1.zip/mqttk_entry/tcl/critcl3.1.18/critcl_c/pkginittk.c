
# line 1 "MyInitTkStubs"
#if USE_TK_STUBS
  if (!MyInitTkStubs(interp)) return TCL_ERROR;
#endif
